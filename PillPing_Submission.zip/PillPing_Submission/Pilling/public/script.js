
// PILLPING - CARECIRCLE

let medicines = JSON.parse(localStorage.getItem("medicines")) || [];
let history = JSON.parse(localStorage.getItem("history")) || [];
let currentReminder = null;
let reminderShown = [];

// Save information
function saveData() {
    localStorage.setItem("medicines", JSON.stringify(medicines));
    localStorage.setItem("history", JSON.stringify(history));
}

// Get today's date
function today() {
    return new Date().toLocaleDateString("en-CA");
}

// Convert medicine time into a clock time
function getScheduleTime(time) {
    if (time === "Morning") return "08:00";
    if (time === "Afternoon") return "13:00";
    return "20:00";
}

// Change pages
function showPage(page) {
    document.querySelectorAll(".page").forEach(section => {
        section.classList.add("hidden");
    });

    document.getElementById(page).classList.remove("hidden");

    updateDashboard();
}

// Add medicine
document.getElementById("medicineForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const medicine = {
        id: Date.now(),
        name: document.getElementById("medicineName").value.trim(),
        dosage: document.getElementById("dosage").value.trim(),
        time: document.getElementById("medicineTime").value,
        food: document.getElementById("food").value,
        refill: Number(document.getElementById("refill").value)
    };

    medicines.push(medicine);

    saveData();

    this.reset();

    alert("Medicine added successfully!");

    updateDashboard();
    showPage("home");
});

// Get today's record
function getRecord(id) {
    return history.find(item =>
        item.id === id && item.date === today()
    );
}

// Get medicine status
function getStatus(medicine) {
    const record = getRecord(medicine.id);

    if (record && record.status === "Taken") {
        return "Taken";
    }

    const schedule = getScheduleTime(medicine.time);
    const scheduledDate = new Date(today() + "T" + schedule + ":00");
    const now = new Date();

    if (now.getTime() >= scheduledDate.getTime() + 30 * 60000) {
        return "Missed";
    }

    return "Pending";
}

// Display medicine card
function createMedicineCard(medicine) {
    const status = getStatus(medicine);

    const card = document.createElement("div");
    card.className = "medicine-card";

    const title = document.createElement("h3");
    title.textContent = "💊 " + medicine.name;

    const dosage = document.createElement("p");
    dosage.textContent = "Dosage: " + medicine.dosage;

    const time = document.createElement("p");
    time.textContent = "Time: " + medicine.time;

    const food = document.createElement("p");
    food.textContent = "Instructions: " + medicine.food;

    const refill = document.createElement("p");
    refill.textContent = "Remaining doses: " + medicine.refill;

    if (medicine.refill < 5) {
        const warning = document.createElement("p");
        warning.textContent = "⚠️ Low Stock! Please refill this medicine.";
        warning.style.color = "red";
        warning.style.fontWeight = "bold";
        card.appendChild(warning);
    }

    const statusText = document.createElement("p");
    statusText.textContent = "Status: " + status;

    if (status === "Taken") {
        statusText.style.color = "green";
    } else if (status === "Missed") {
        statusText.style.color = "red";
    } else {
        statusText.style.color = "#b36b00";
    }

    card.append(title, dosage, time, food, refill, statusText);

    if (status === "Pending") {
        const button = document.createElement("button");
        button.className = "taken-btn";
        button.textContent = "I Took My Medicine";
        button.addEventListener("click", () => confirmMedicine(medicine.id));
        card.appendChild(button);
    }

    if (status === "Taken") {
        const success = document.createElement("p");
        success.textContent = "✅ Good job! Medicine completed.";
        card.appendChild(success);
    }

    return card;
}

// Display all medicines
function displayMedicines() {
    const list = document.getElementById("medicineList");
    const saved = document.getElementById("savedMedicines");

    list.innerHTML = "";
    saved.innerHTML = "";

    if (medicines.length === 0) {
        list.textContent = "No medicines added yet.";
        saved.textContent = "Please add your first medicine.";
        return;
    }

    medicines.forEach(medicine => {
        list.appendChild(createMedicineCard(medicine));
        saved.appendChild(createMedicineCard(medicine));
    });
}

// Confirm medicine
function confirmMedicine(id) {
    const medicine = medicines.find(item => item.id === id);

    if (!medicine || getRecord(id)?.status === "Taken") return;

    history.push({
        id: id,
        date: today(),
        status: "Taken",
        takenAt: new Date().toLocaleTimeString()
    });

    medicine.refill = Math.max(0, medicine.refill - 1);

    saveData();

    document.getElementById("reminder").classList.add("hidden");

    currentReminder = null;

    alert("Good job! Medicine confirmed successfully.");

    updateDashboard();
}

// Snooze reminder
document.getElementById("snoozeButton").addEventListener("click", function () {
    if (!currentReminder) return;

    const medicine = medicines.find(item => item.id === currentReminder);

    if (!medicine) return;

    const key = today() + "-" + medicine.id;

    localStorage.setItem("snooze-" + key, Date.now() + 15 * 60000);

    document.getElementById("reminder").classList.add("hidden");

    reminderShown = reminderShown.filter(item => item !== key);

    currentReminder = null;

    alert("Reminder snoozed for 15 minutes.");
});

// Open reminder
function openReminder(medicine) {
    currentReminder = medicine.id;

    document.getElementById("reminderName").textContent = medicine.name;
    document.getElementById("reminderDosage").textContent = "Dosage: " + medicine.dosage;
    document.getElementById("reminderInstructions").textContent =
        medicine.food + " | " + medicine.time;

    document.getElementById("reminder").classList.remove("hidden");

    document.getElementById("takenButton").onclick = function () {
        confirmMedicine(medicine.id);
    };

    // Read instructions aloud
    if ("speechSynthesis" in window) {
        const speech = new SpeechSynthesisUtterance(
            "Time to take your medicine. " +
            medicine.name + ". " +
            medicine.dosage + ". " +
            medicine.food
        );

        speechSynthesis.cancel();
        speechSynthesis.speak(speech);
    }
}

// Check medicine reminders
function checkReminders() {
    const now = new Date();

    medicines.forEach(medicine => {
        if (getRecord(medicine.id)?.status === "Taken") return;

        const key = today() + "-" + medicine.id;

        const schedule = getScheduleTime(medicine.time);
        const scheduledDate = new Date(today() + "T" + schedule + ":00");

        const snoozeUntil = Number(
            localStorage.getItem("snooze-" + key) || 0
        );

        const isDue = now >= scheduledDate;

        if (
            isDue &&
            Date.now() >= snoozeUntil &&
            !reminderShown.includes(key)
        ) {
            reminderShown.push(key);
            openReminder(medicine);
        }
    });

    updateDashboard();
}

// Update caregiver dashboard and home page
function updateDashboard() {
    const taken = medicines.filter(m => getStatus(m) === "Taken").length;
    const missed = medicines.filter(m => getStatus(m) === "Missed").length;
    const pending = medicines.filter(m => getStatus(m) === "Pending").length;

    document.getElementById("totalMedicines").textContent = medicines.length;
    document.getElementById("completedMedicines").textContent = taken;
    document.getElementById("pendingMedicines").textContent = pending;

    document.getElementById("caregiverTaken").textContent = taken;
    document.getElementById("caregiverPending").textContent = pending;
    document.getElementById("caregiverMissed").textContent = missed;

    const caregiverList = document.getElementById("caregiverList");
    caregiverList.innerHTML = "";

    medicines.forEach(medicine => {
        caregiverList.appendChild(createMedicineCard(medicine));
    });

    // Missed dose alerts
    const alerts = document.getElementById("alerts");
    alerts.innerHTML = "";

    const missedMedicines = medicines.filter(m => getStatus(m) === "Missed");

    if (missedMedicines.length === 0) {
        alerts.textContent = "No alerts at present.";
    } else {
        missedMedicines.forEach(medicine => {
            const alert = document.createElement("p");
            alert.textContent = "⚠️ ALERT: " + medicine.name + " has not been confirmed.";
            alert.style.color = "red";
            alerts.appendChild(alert);

            if ("Notification" in window && Notification.permission === "granted") {
                const notificationKey = "alert-" + today() + "-" + medicine.id;

                if (!localStorage.getItem(notificationKey)) {
                    new Notification("PillPing Missed Dose Alert", {
                        body: medicine.name + " has not been confirmed."
                    });

                    localStorage.setItem(notificationKey, "sent");
                }
            }
        });
    }

    updateHistory();
}

// Weekly adherence
function updateHistory() {
    const takenCount = history.filter(item =>
        item.status === "Taken" &&
        (new Date(today()) - new Date(item.date)) / 86400000 < 7
    ).length;

    const totalDoses = medicines.length * 7;

    const percentage = totalDoses > 0
        ? Math.min(100, Math.round(takenCount / totalDoses * 100))
        : 0;

    document.getElementById("adherence").textContent = percentage + "%";

    const historyList = document.getElementById("historyList");
    historyList.innerHTML = "<h3>Last 7 Days</h3>";

    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);

        const dateString = date.toLocaleDateString("en-CA");

        const count = history.filter(item =>
            item.date === dateString && item.status === "Taken"
        ).length;

        const day = document.createElement("div");
        day.className = "medicine-card";
        day.textContent =
            date.toDateString() + " — " + count + " dose(s) completed";

        historyList.appendChild(day);
    }
}

// Display Weekly Calendar
const calendar = document.getElementById("weeklyCalendar");

if (calendar) {
    calendar.innerHTML = "";

    for (let i = 6; i >= 0; i--) {
        const dateObj = new Date();
        dateObj.setDate(dateObj.getDate() - i);

        const date = dateObj.toLocaleDateString("en-CA");
        const day = dateObj.toLocaleDateString("en-US", {
            weekday: "short"
        });

        const taken = history.some(item => item.date === date);

        let status = "pending";

        if (taken) {
            status = "taken";
        } else if (date < today() && medicines.length > 0) {
            status = "missed";
        }

        calendar.innerHTML += `
            <div class="calendar-day ${status}">
                <div>${day}</div>
                <div>${dateObj.getDate()}</div>
                <small>${status.toUpperCase()}</small>
            </div>
        `;
    }
}

// Request notification permission
if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission();
}

// Emergency SOS
function emergencySOS() {
    alert("Emergency! Please contact your designated caregiver.");
}

// Start application
displayMedicines();
updateDashboard();

setInterval(checkReminders, 10000);
checkReminders();



function emergencySOS() {
    const confirmSOS = confirm(
        "Are you sure you want to send an emergency alert?"
    );

    if (confirmSOS) {
        alert(
            "🚨 Emergency Alert Activated!\n\nPlease contact your caregiver immediately."
        );
    } else {
        alert("Emergency alert cancelled.");
    }
}
