
const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());

// Serve frontend files
app.use(express.static(path.join(__dirname, "public")));

// Home route
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Test route
app.get("/api/status", (req, res) => {
    res.json({
        message: "PillPing server is running successfully!",
        status: "Online"
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`PillPing server running at http://localhost:${PORT}`);
});